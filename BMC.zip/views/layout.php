<?php
require 'header.php';

require "views/footer.php";
?>
<footer class="footer">
		<p>An <a href="http://a-studio.me">a-studio</a> product</p>
	</footer>
	</body>
</html>